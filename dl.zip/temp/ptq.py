import os 
import sys 
from pathlib import Path 
from time import perf_counter
from itertools import islice 
from datetime import datetime

import toml 
import torch 
import numpy as np 
from tqdm import tqdm 

from brevitas.graph.calibrate import calibration_mode 

from quant_utils import load_q_model, init 
from data import DataSettings, ModelSetup, ComputeSettings, load_data
from utils import decode_ref, permute, accuracy, tqdm_environ
from io_utils import CSVLogger

__dir__ = Path(__file__).parent

class PTQArguments:
    pretrained_weights = __dir__ / "models"/"quant_sup@v5.0.0"
    config_path = __dir__ / "models" / "quant_sup@v5.0.0" / "quant_config.toml"
    data_dir = __dir__ /"data" / "example_data_dna_r10.4.1_v0"
    output_dir = __dir__ / "ptq_output"

    device = "cuda" if torch.cuda.is_available() else "cpu"

    seed = 42 
    num_workers = 4 
    batch_size = 4 
    calibration_steps = 300 
    calibration_chunks = batch_size * calibration_steps

    validation_chunks = 2000
    force_overwrite = True 
    checkpoint_name = "INT_QKV8_FFN4"


def calibrate_model(model, train_loader, steps, device):

    model.eval()
    print(f"\n[PTQ MODEL CALIBRATION] Streaming {steps} batches ({steps * 4} chunks) through calibration mode")
    t0 = perf_counter()

    pbar = tqdm(total=steps, desc= "[PTQ MODEL CALIBRATION]", ascii=True, ncols=100)

    with torch.no_grad():
        with calibration_mode(model):
            for batch in islice(train_loader, steps):
                data = batch[0].to(device)

                _ = model(data)
                pbar.update(1)
    pbar.close()

    duration = perf_counter() - t0 

    print(f"[MODEL CALIBRATION COMPLETE] Finished in {duration: .1f}s. All quantizer scales frozen.")
    return duration 


def evaluate_model(model, valid_loader, device):

    model.eval() 
    print(f"\n[PTQ MODEL VALIDATION]")
    t0 = perf_counter()


    n_pre = getattr(model, "n_pre_context_bases", 0)
    n_post = getattr(model, "n_post_context_bases", 0)

    accs = [] 
    pbar = tqdm(valid_loader, desc="[EVALUATING]", ascii=True, ncols=100)

    with torch.no_grad():
        for batch in pbar:
            data, targets, lengths, *args = (x.to(device) for x in batch)
            scores = model(data)



            if hasattr(model, "decode_batch"):
                seqs = model.decode_batch(scores)

            else:
                 print("WARNING MIGHT WANNA CHECK OUT")
                 seqs = [model.decode(x) for x in permute(scores, "TNC", "NTC")]

            refs = [decode_ref(t, model.alphabet) for t in targets]
            if n_pre >0 or n_post > 0:
                refs = [r[n_pre : len(r) - n_post] for r in refs]


            batch_accs = [
                accuracy(ref, seq, min_coverage=0.5) if len(seq) and len(ref) else 0.0 for ref, seq in zip(refs, seqs)
            ]

            accs.extend(batch_accs)

            pbar.set_postfix(mean_acc=f"{np.mean(accs):.2f}%")


    duration = perf_counter() - t0 
    mean_acc = float(np.mean(accs))
    median_acc = float(np.median(accs))

    print("=" * 60)
    print(f"[PTQ EVALUATION RESULTS]")
    print(f"  * Total Chunks Evaluated: {len(accs)}")
    print(f"  * Mean Accuracy         : {mean_acc:.3f}%")
    print(f"  * Median Accuracy       : {median_acc:.3f}%")
    print(f"  * Evaluation Time       : {duration:.1f}s")
    print("=" * 60)
    return mean_acc, median_acc



def main():
    cfg = PTQArguments()
    init(cfg.seed, cfg.device, True)
    workdir = Path(cfg.output_dir)
    workdir.mkdir(parents=True, exist_ok=True)
    # 1. Load Configurations & Model
    print(f"[1/4] Loading model config from {cfg.config_path}...")
    config = toml.load(cfg.config_path)
    print(f"[2/4] Loading FP32 pretrained weights from {cfg.pretrained_weights}...")
    model = load_q_model(cfg.pretrained_weights, cfg.device, "FP32")
    model.to(cfg.device)
    # 2. Data Loaders
    print(f"[3/4] Initializing datasets from {cfg.data_dir}...")
    data_settings = DataSettings(
        training_data=cfg.data_dir,
        num_train_chunks=cfg.calibration_chunks,
        num_valid_chunks=cfg.validation_chunks,
        output_dir=cfg.output_dir,
    )
    model_setup = ModelSetup(
        n_pre_context_bases=getattr(model, "n_pre_context_bases", 0),
        n_post_context_bases=getattr(model, "n_post_context_bases", 0),
        standardisation=config.get("standardisation", {}),
    )
    compute_settings = ComputeSettings(
        batch_size=cfg.batch_size,
        num_workers=cfg.num_workers,
        seed=cfg.seed,
    )
    train_loader, valid_loader = load_data(data_settings, model_setup, compute_settings)
    # 3. Calibration
    calib_duration = calibrate_model(model, train_loader, cfg.calibration_steps, cfg.device)
    # 4. Save Calibrated Model (Weights + Frozen Scale Buffers)
    checkpoint_path = workdir / f"{cfg.checkpoint_name}_weights_0.tar" 
    for mod in model.modules():
        if hasattr(mod, 'quant_weight'):
            _ = mod.quant_weight()
    model_state = model.module.state_dict() if hasattr(model, "module") else model.state_dict()
    torch.save(model_state, checkpoint_path)
    print(f"[CHECKPOINT] Saved calibrated weights to {checkpoint_path}")
    # Save matching config.toml
    with open(workdir / "config.toml", "w") as f:
        toml.dump(config, f)
    # Also save quant_config.toml for seamless loading by load_q_model
    with open(workdir / "quant_config.toml", "w") as f:
        toml.dump(config, f)
    # 5. Validation
    mean_acc, median_acc = evaluate_model(model, valid_loader, cfg.device)
    # 6. Log Results
    with CSVLogger(workdir / "ptq_results.csv") as log:
        log.append({
            "timestamp": datetime.today(),
            "duration_seconds": int(calib_duration),
            "validation_mean_acc": mean_acc,
            "validation_median_acc": median_acc,
        })
    print(f"[COMPLETE] PTQ results logged to {workdir / 'ptq_results.csv'}")
if __name__ == "__main__":
    main()
