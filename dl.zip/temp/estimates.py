#!/usr/bin/env python3
"""
estimates.py: Model Parameter Breakdown and Memory Estimator for Oxford Nanopore Transformer Basecaller.
Computes exact parameter counts, layer percentages, and precision memory footprints (FP32, INT8, INT4)
for the CNN frontend, 18-layer Transformer encoder stack, Linear Upsampler, and Linear CRF Encoder.
"""

import os
import sys
import argparse
from pathlib import Path
import toml
import torch

# Ensure local imports work
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from model import Model


def format_num(n: int) -> str:
    """Format integers with commas."""
    return f"{n:,}"


def bytes_to_human(n_bytes: float) -> str:
    """Format bytes to KB / MB."""
    if n_bytes >= 1024 * 1024:
        return f"{n_bytes / (1024 * 1024):.2f} MB"
    elif n_bytes >= 1024:
        return f"{n_bytes / 1024:.2f} KB"
    else:
        return f"{n_bytes:.0f} B"


def find_default_config() -> Path:
    """Locate the default configuration file."""
    candidates = [
        SCRIPT_DIR / "output" / "config.toml",
        SCRIPT_DIR / "models" / "dna_r10.4.1_e8.2_400bps_sup@v5.0.0" / "config.toml",
        SCRIPT_DIR / "models" / "config.toml",
    ]
    for c in candidates:
        if c.is_file():
            return c
    return candidates[0]


def print_section(title: str, width: int = 88):
    print("\n" + "=" * width)
    print(f"  {title}")
    print("=" * width)


def generate_estimates(config_path: str, print_latex: bool = False):
    config_file = Path(config_path)
    if not config_file.is_file():
        print(f"Error: Configuration file not found at '{config_file}'")
        sys.exit(1)

    print(f"[INFO] Loading configuration from: {config_file}")
    config = toml.load(config_file)

    # Instantiate model purely from config (zero-GPU, zero-weights required)
    try:
        model = Model(config)
    except Exception as e:
        print(f"Error instantiating model: {e}")
        sys.exit(1)

    total_params = sum(p.numel() for p in model.parameters())

    # 1. Component Parameter Extraction
    conv_module = model.encoder.conv
    transformer_module = model.encoder.transformer_encoder
    upsample_module = model.encoder.upsample
    crf_module = model.encoder.crf

    conv_params = sum(p.numel() for p in conv_module.parameters())
    transformer_params = sum(p.numel() for p in transformer_module.parameters())
    upsample_params = sum(p.numel() for p in upsample_module.parameters())
    crf_params = sum(p.numel() for p in crf_module.parameters())

    conv_pct = (conv_params / total_params) * 100
    transformer_pct = (transformer_params / total_params) * 100
    upsample_pct = (upsample_params / total_params) * 100
    crf_pct = (crf_params / total_params) * 100

    # 2. Executive Summary Table
    print_section("EXECUTIVE ARCHITECTURAL SUMMARY & PARAMETER BREAKDOWN")
    header = (
        f"{'Component':<28} | {'Params':>12} | {'% Total':>8} | "
        f"{'FP32 Size':>10} | {'INT8 Size':>10} | {'INT4 Size':>10} | {'Target'}"
    )
    separator = "-" * len(header)
    print(header)
    print(separator)

    components = [
        ("1. CNN Downsample Frontend", conv_params, conv_pct, "Host (FP32)"),
        ("2. 18-Layer Transformer Stack", transformer_params, transformer_pct, "FPGA PL (INT8/4)"),
        ("3. Linear Upsampler (2x)", upsample_params, upsample_pct, "Host (FP32)"),
        ("4. Linear CRF Decoder", crf_params, crf_pct, "Host (FP32)"),
    ]

    for name, p_count, pct, target in components:
        fp32_sz = bytes_to_human(p_count * 4)
        int8_sz = bytes_to_human(p_count * 1)
        int4_sz = bytes_to_human(p_count * 0.5)
        print(
            f"{name:<28} | {format_num(p_count):>12} | {pct:>7.2f}% | "
            f"{fp32_sz:>10} | {int8_sz:>10} | {int4_sz:>10} | {target}"
        )

    print(separator)
    total_fp32 = bytes_to_human(total_params * 4)
    total_int8 = bytes_to_human(total_params * 1)
    total_int4 = bytes_to_human(total_params * 0.5)
    print(
        f"{'TOTAL FULL MODEL':<28} | {format_num(total_params):>12} | {'100.00%':>8} | "
        f"{total_fp32:>10} | {total_int8:>10} | {total_int4:>10} | Mixed Partition"
    )

    # 3. Deep Dive: CNN Frontend (Conv1D Layers)
    print_section("1. CNN FRONTEND LAYER-BY-LAYER BREAKDOWN")
    conv_header = f"{'Sublayer':<24} | {'Kernel / Specs':<24} | {'Weights':>10} | {'Biases':>8} | {'Total Params':>12}"
    print(conv_header)
    print("-" * len(conv_header))

    sub_idx = 0
    for sub in conv_module:
        if hasattr(sub, "conv"):
            k_len = sub.conv.kernel_size[0]
            stride = sub.conv.stride[0]
            in_c = sub.conv.in_channels
            out_c = sub.conv.out_channels
            w_count = sub.conv.weight.numel()
            b_count = sub.conv.bias.numel() if sub.conv.bias is not None else 0
            # BN params
            bn_w = sub.norm.bn.weight.numel() if hasattr(sub.norm, "bn") and sub.norm.bn.weight is not None else 0
            bn_b = sub.norm.bn.bias.numel() if hasattr(sub.norm, "bn") and sub.norm.bn.bias is not None else 0
            total_sub = w_count + b_count + bn_w + bn_b
            specs = f"k={k_len}, s={stride}, {in_c}->{out_c}"
            name = f"Conv1D Layer {sub_idx}"
            print(f"{name:<24} | {specs:<24} | {format_num(w_count):>10} | {format_num(b_count + bn_w + bn_b):>8} | {format_num(total_sub):>12}")
            sub_idx += 1
        elif hasattr(sub, "dims"):
            print(f"{'Permute [0, 2, 1]':<24} | {'Dimension reorder':<24} | {'0':>10} | {'0':>8} | {'0':>12}")

    print("-" * len(conv_header))
    print(f"{'Total CNN Frontend':<24} | {'Stride = 12 total':<24} | {'':>10} | {'':>8} | {format_num(conv_params):>12}")

    # 4. Deep Dive: Transformer Layer
    n_layers = len(transformer_module)
    single_layer = transformer_module[0]
    single_layer_params = sum(p.numel() for p in single_layer.parameters())

    wqkv_w = single_layer.self_attn.Wqkv.weight.numel()
    wqkv_b = single_layer.self_attn.Wqkv.bias.numel() if single_layer.self_attn.Wqkv.bias is not None else 0
    wo_w = single_layer.self_attn.out_proj.weight.numel()
    wo_b = single_layer.self_attn.out_proj.bias.numel() if single_layer.self_attn.out_proj.bias is not None else 0

    fc1_w = single_layer.ff.fc1.weight.numel()
    fc1_b = single_layer.ff.fc1.bias.numel() if single_layer.ff.fc1.bias is not None else 0
    fc2_w = single_layer.ff.fc2.weight.numel()
    fc2_b = single_layer.ff.fc2.bias.numel() if single_layer.ff.fc2.bias is not None else 0

    norm1_params = sum(p.numel() for p in single_layer.norm1.parameters())
    norm2_params = sum(p.numel() for p in single_layer.norm2.parameters())

    print_section(f"2. TRANSFORMER STACK BREAKDOWN ({n_layers} Identical Layers)")
    tf_header = f"{'Sub-Module':<28} | {'Shape':<16} | {'Params / Layer':>14} | {'% of Layer':>10} | {'All 18 Layers':>14}"
    print(tf_header)
    print("-" * len(tf_header))

    tf_submodules = [
        ("Multi-Head QKV Proj (Wqkv)", "512 -> 1536", wqkv_w + wqkv_b),
        ("Multi-Head Out Proj (W_O)", "512 -> 512", wo_w + wo_b),
        ("SwiGLU Up & Gate (fc1)", "512 -> 4096", fc1_w + fc1_b),
        ("SwiGLU Down Proj (fc2)", "2048 -> 512", fc2_w + fc2_b),
        ("RMSNorm 1 (Attention Residual)", "512", norm1_params),
        ("RMSNorm 2 (FFN Residual)", "512", norm2_params),
    ]

    for name, shape, count in tf_submodules:
        layer_pct = (count / single_layer_params) * 100
        total_18 = count * n_layers
        print(f"{name:<28} | {shape:<16} | {format_num(count):>14} | {layer_pct:>9.2f}% | {format_num(total_18):>14}")

    print("-" * len(tf_header))
    print(
        f"{'Single Layer Total':<28} | {'d_model = 512':<16} | {format_num(single_layer_params):>14} | {'100.00%':>10} | {format_num(transformer_params):>14}"
    )

    # 5. Deep Dive: Linear Upsampler and Linear CRF Decoder
    print_section("3 & 4. LINEAR UPSAMPLER & LINEAR CRF DECODER")
    up_w = upsample_module.linear.weight.numel()
    up_b = upsample_module.linear.bias.numel() if upsample_module.linear.bias is not None else 0

    crf_w = crf_module.linear.weight.numel()
    crf_b = crf_module.linear.bias.numel() if crf_module.linear.bias is not None else 0

    other_header = f"{'Component':<28} | {'Spec / Mapping':<26} | {'Params':>12} | {'% Total':>8}"
    print(other_header)
    print("-" * len(other_header))
    print(
        f"{'Linear Upsampler (2x)':<28} | {'512 -> 1024 (Scale = 2)':<26} | {format_num(upsample_params):>12} | {upsample_pct:>7.2f}%"
    )
    print(
        f"{'Linear CRF Decoder':<28} | {'512 -> 4096 (4^5 states)':<26} | {format_num(crf_params):>12} | {crf_pct:>7.2f}%"
    )
    print("-" * len(other_header))

    # 6. Key Research Takeaways (Perfect for your 2-page paper!)
    print_section("KEY RESEARCH TAKEAWAYS FOR YOUR 2-PAGE SRS PAPER")
    print(f" • Bulk Compute Offloading: The 18-layer Transformer encoder accounts for")
    print(f"   EXACTLY {transformer_pct:.2f}% of all model parameters ({format_num(transformer_params)} of {format_num(total_params)}).")
    print(f"   Offloading this module to FPGA Programmable Logic accelerates >95% of the model workload.")
    print()
    print(f" • Host Pre/Post-processing Footprint: Conv1D ({conv_pct:.2f}%), LinearUpsample ({upsample_pct:.2f}%),")
    print(f"   and LinearCRF ({crf_pct:.2f}%) combined represent ONLY {conv_pct + upsample_pct + crf_pct:.2f}% of model parameters.")
    print(f"   Keeping them on the Host in FP32 preserves raw analog signal fidelity and emission score precision")
    print(f"   without sacrificing hardware compute density.")
    print()
    print(f" • Memory Footprint per Transformer Layer:")
    print(f"   - FP32: {bytes_to_human(single_layer_params * 4)}")
    print(f"   - INT8: {bytes_to_human(single_layer_params * 1)} (~4.00 MB pure matrix weights)")
    print(f"   - INT4: {bytes_to_human(single_layer_params * 0.5)} (~2.00 MB pure matrix weights)")

    # 7. Optional LaTeX Table Output
    if print_latex:
        print_section("LATEX TABLE CODE (Copy & Paste directly into your Paper)")
        latex_code = rf"""\begin{{table}}[t]
\centering
\caption{{Model Parameter Distribution and Heterogeneous Execution Partitioning}}
\label{{tab:param_breakdown}}
\resizebox{{\columnwidth}}{{!}}{{%
\begin{{tabular}}{{lrrrrr}}
\toprule
\textbf{{Pipeline Stage}} & \textbf{{Parameters}} & \textbf{{\% Total}} & \textbf{{FP32 Size}} & \textbf{{INT8 Size}} & \textbf{{Execution Target}} \\
\midrule
1. CNN Frontend (5x Conv1D) & {conv_params:,} & {conv_pct:.2f}\% & {bytes_to_human(conv_params*4)} & {bytes_to_human(conv_params*1)} & Host CPU (FP32) \\
2. 18x Transformer Encoder  & {transformer_params:,} & {transformer_pct:.2f}\% & {bytes_to_human(transformer_params*4)} & {bytes_to_human(transformer_params*1)} & \textbf{{FPGA PL (INT8)}} \\
3. Linear Upsampler (2x)    & {upsample_params:,} & {upsample_pct:.2f}\% & {bytes_to_human(upsample_params*4)} & {bytes_to_human(upsample_params*1)} & Host CPU (FP32) \\
4. Linear CRF Decoder       & {crf_params:,} & {crf_pct:.2f}\% & {bytes_to_human(crf_params*4)} & {bytes_to_human(crf_params*1)} & Host CPU (FP32) \\
\midrule
\textbf{{Full Model Total}} & \textbf{{{total_params:,}}} & \textbf{{100.00\%}} & \textbf{{{total_fp32}}} & \textbf{{{total_int8}}} & \textbf{{Heterogeneous}} \\
\bottomrule
\end{{tabular}}%
}}
\end{{table}}"""
        print(latex_code)

    print("\n[SUCCESS] Parameter estimation complete.\n")


def main():
    parser = argparse.ArgumentParser(
        description="Calculate model parameter distribution, layer percentages, and memory footprints."
    )
    parser.add_argument(
        "--config",
        type=str,
        default=str(find_default_config()),
        help="Path to model config.toml file (default: auto-detected in output/ or models/)",
    )
    parser.add_argument(
        "--latex",
        action="store_true",
        help="Print ready-to-paste LaTeX table code for research papers.",
    )
    args = parser.parse_args()
    generate_estimates(args.config, args.latex)


if __name__ == "__main__":
    main()
