"""
Bonito train
"""

import math
import os
import re
from glob import glob
from itertools import islice
from time import perf_counter
from collections import OrderedDict, defaultdict
from datetime import datetime
from pathlib import Path

import parasail
from schedule import linear_warmup_cosine_decay
from utils import accuracy, decode_ref, permute, match_names, tqdm_environ, load_object
from io_utils import CSVLogger

import torch
import numpy as np
from tqdm import tqdm
import torch.amp as amp




def load_state(dirname, device, model, optim=None):
    """
    Load a model state dict from disk
    """
    dirname = Path(dirname)
    model.to(device)
    if hasattr(model, "module"):
        model = model.module

    to_load = [("weights", model)]
    weight_files = dirname.glob("weights_*.tar")
    weight_nos = {int(w.stem.split("_")[-1]) for w in weight_files}

    if optim is not None:
        to_load.append(("optim", optim))
        optim_files = dirname.glob("optim_*.tar")
        optim_nos = {int(w.stem.split("_")[-1]) for w in optim_files}
        weight_no = max(optim_nos & weight_nos, default=None)
    else:
        weight_no = max(weight_nos, default=None)

    if weight_no is None:
        return 0

    for name, obj in to_load:
        print(f"[loading state] - {name}_{weight_no}.tar")
        state_dict = torch.load(
            dirname / f"{name}_{weight_no}.tar",
            map_location=device,
            weights_only=False,
        )
        if name == "weights":
            state_dict = {
                k2.replace('module.', ''): state_dict[k1]
                for k1, k2 in match_names(state_dict, obj).items()
            }
        obj.load_state_dict(state_dict)

    return weight_no


class ClipGrad:
    def __init__(self, quantile=0.5, factor=2.0, buffer_size=100):
        self.buffer = np.full(buffer_size, fill_value=1e6)
        self.quantile = quantile
        self.factor = factor
        self.i = 0

    def append(self, grad_norm):
        self.buffer[self.i] = grad_norm
        self.i = (self.i + 1) % len(self.buffer)

    def __call__(self, parameters):
        max_norm = self.factor * np.quantile(self.buffer, self.quantile)
        grad_norm = torch.nn.utils.clip_grad_norm_(parameters, max_norm=max_norm).item()
        if math.isfinite(grad_norm):
            self.append(grad_norm)
        return grad_norm


class Trainer:
    def __init__(
        self, model, device, train_loader, valid_loader, criterion=None,
        use_amp=True, lr_scheduler_fn=None, restore_optim=False,
        save_optim_every=10, grad_accum_split=1, quantile_grad_clip=False,
        chunks_per_epoch=None, batch_size=None, fixed_grad_scale=None
    ):
        self.model = model.to(device)
        self.device = device
        self.train_loader = train_loader
        self.valid_loader = valid_loader
        self.criterion = criterion or model.loss
        self.use_amp = use_amp
        self.lr_scheduler_fn = lr_scheduler_fn or linear_warmup_cosine_decay()
        self.restore_optim = restore_optim
        self.save_optim_every = save_optim_every
        self.grad_accum_split = grad_accum_split

        self.fixed_grad_scale = fixed_grad_scale
        self.scaler = torch.amp.GradScaler(
            "cuda",
            enabled=use_amp,
            **({"init_scale": fixed_grad_scale} if fixed_grad_scale else {})
        )

        self.optimizer = None
        if quantile_grad_clip:
            self.clip_grad = ClipGrad()
        else:
            self.clip_grad = lambda parameters: torch.nn.utils.clip_grad_norm_(parameters, max_norm=2.0).item()

        self.batch_size = batch_size
        self.chunks_per_epoch = chunks_per_epoch
        self.steps_per_epoch = chunks_per_epoch // batch_size

    def train_one_step(self, batch):
        self.optimizer.zero_grad()
        losses = None

        for batch_ in zip(
            *map(lambda t: t.chunk(self.grad_accum_split, dim=0), batch)
        ):
            data_, targets_, lengths_, *args = (x.to(self.device) for x in batch_)

            with amp.autocast("cuda", enabled=self.use_amp):
                scores_ = self.model(data_, *args)
                losses_ = self.criterion(scores_, targets_, lengths_)

            if not isinstance(losses_, dict): losses_ = {'loss': losses_}

            total_loss = losses_.get('total_loss', losses_['loss']) / self.grad_accum_split
            self.scaler.scale(total_loss).backward()

            losses = {
                k: ((v.item() / self.grad_accum_split) if losses is None else (v.item() / self.grad_accum_split) + losses[k])
                for k, v in losses_.items()
            }

        scale = self.scaler.get_scale()
        self.scaler.unscale_(self.optimizer)
        grad_norm = self.clip_grad(self.model.parameters())
        self.scaler.step(self.optimizer)
        self.scaler.update(self.fixed_grad_scale)

        return losses, grad_norm, scale

    def train_one_epoch(self, loss_log, lr_scheduler):
        t0 = perf_counter()
        chunks = 0
        self.model.train()

        # total is in batches and desc represents the number of training chunks supplied
        progress_bar = tqdm(
            total=self.steps_per_epoch, desc='[0/{}]'.format(self.chunks_per_epoch),
            ascii=True, leave=True, ncols=100, bar_format='{l_bar}{bar}| [{elapsed}{postfix}]',
            **tqdm_environ()
        )
        smoothed_loss = None

        with progress_bar:

            for batch in islice(self.train_loader, self.steps_per_epoch):
                chunks += batch[0].shape[0]
                losses, grad_norm, scale = self.train_one_step(batch)

                smoothed_loss = losses['loss'] if smoothed_loss is None else (0.01 * losses['loss'] + 0.99 * smoothed_loss)

                progress_bar.set_postfix(loss='%.4f' % smoothed_loss)
                progress_bar.set_description("[{}/{}]".format(chunks, self.chunks_per_epoch))
                progress_bar.update()

                if loss_log is not None:
                    lr = lr_scheduler.get_last_lr()
                    if len(lr) == 1: lr = lr[0]
                    loss_log.append({
                        'chunks': chunks,
                        'time': perf_counter() - t0,
                        'grad_norm': grad_norm,
                        'lr': lr,
                        'scale': scale,
                        **losses
                    })

                if lr_scheduler is not None: lr_scheduler.step()

        return smoothed_loss, perf_counter() - t0

    def validate_one_step(self, batch):
        data, targets, lengths, *args = batch
        with amp.autocast("cuda", enabled=self.use_amp):
            scores = self.model(data.to(self.device), *(x.to(self.device) for x in args))
            losses = self.criterion(scores, targets.to(self.device), lengths.to(self.device))
        losses = {k: v.item() for k, v in losses.items()} if isinstance(losses, dict) else losses.item()
        if hasattr(self.model, 'decode_batch'):
            seqs = self.model.decode_batch(scores)
        else:
            seqs = [self.model.decode(x) for x in permute(scores, 'TNC', 'NTC')]
        refs = [decode_ref(target, self.model.alphabet) for target in targets]

        n_pre = getattr(self.model, "n_pre_context_bases", 0)
        n_post = getattr(self.model, "n_post_context_bases", 0)
        if n_pre > 0 or n_post > 0:
            refs = [ref[n_pre:len(ref)-n_post] for ref in refs]

        accs = [
            accuracy(ref, seq, min_coverage=0.5) if len(seq) and len(ref) else 0.0
            for ref, seq in zip(refs, seqs)
        ]
        return seqs, refs, accs, losses

    def validate_one_epoch(self):
        self.model.eval()
        with torch.no_grad():
            seqs, refs, accs, losses = zip(*(self.validate_one_step(batch) for batch in self.valid_loader))
        seqs, refs, accs = (sum(x, []) for x in (seqs, refs, accs))
        loss = np.mean([(x['loss'] if isinstance(x, dict) else x) for x in losses])
        return loss, np.mean(accs), np.median(accs)

    def init_optimizer(self, lr, **optim_kwargs):
        if "package" in optim_kwargs:
            optim_cls = load_object(optim_kwargs.pop('package'), optim_kwargs.pop('symbol'))
        else:
            optim_cls = torch.optim.AdamW

        print(f"[loading optim] - '{optim_cls.__name__}' with args: {optim_kwargs}")
        optim_kwargs["lr"] = lr
        self.optimizer = optim_cls(self.model.parameters(), **optim_kwargs)


    def get_lr_scheduler(self, epochs, last_epoch=0):
        return self.lr_scheduler_fn(self.optimizer, self.steps_per_epoch, epochs, last_epoch)

    def fit(self, workdir, epochs=1, lr=2e-3, **optim_kwargs):
        if self.optimizer is None:
            self.init_optimizer(lr, **optim_kwargs)

        last_epoch = load_state(workdir, self.device, self.model, self.optimizer if self.restore_optim else None)

        if self.restore_optim:
        # override learning rate to new value
            for i, pg in enumerate(self.optimizer.param_groups):
                pg["initial_lr"] = pg["lr"] = lr[i] if isinstance(lr, (list, tuple)) else lr

        lr_scheduler = self.get_lr_scheduler(epochs, last_epoch=last_epoch)

        for epoch in range(1 + last_epoch, epochs + 1):
            try:
                with CSVLogger(os.path.join(workdir, 'losses_{}.csv'.format(epoch))) as loss_log:
                    train_loss, duration = self.train_one_epoch(loss_log, lr_scheduler)

                model_state = self.model.module.state_dict() if hasattr(self.model, 'module') else self.model.state_dict()
                torch.save(model_state, os.path.join(workdir, "weights_%s.tar" % epoch))
                if epoch % self.save_optim_every == 0:
                    torch.save(self.optimizer.state_dict(), os.path.join(workdir, "optim_%s.tar" % epoch))

                val_loss, val_mean, val_median = self.validate_one_epoch()
            except KeyboardInterrupt:
                break

            print("[epoch {}] directory={} loss={:.4f} mean_acc={:.3f}% median_acc={:.3f}%".format(
                epoch, workdir, val_loss, val_mean, val_median
            ))

            with CSVLogger(os.path.join(workdir, 'training.csv')) as training_log:
                training_log.append({
                    'time': datetime.today(),
                    'duration': int(duration),
                    'epoch': epoch,
                    'train_loss': train_loss,
                    'validation_loss': val_loss,
                    'validation_mean': val_mean,
                    'validation_median': val_median
                })



class PTQCalibrator:
    def __init__(
        self,
        model,
        device,
        train_loader,
        valid_loader,
        criterion=None,
        use_amp=True,
        chunks_per_epoch=1200,
        batch_size=4,
    ):
        self.model = model.to(device)
        self.device = device
        self.train_loader = train_loader
        self.valid_loader = valid_loader
        self.criterion = criterion or model.loss
        self.use_amp = use_amp
        self.batch_size = batch_size
        self.chunks_per_epoch = chunks_per_epoch
        self.steps_per_epoch = chunks_per_epoch // batch_size
    def calibrate_one_step(self, batch):
        """Runs a single forward pass without backprop to collect activation statistics."""
        data_, targets_, lengths_, *args = (x.to(self.device) for x in batch)
        with amp.autocast("cuda", enabled=self.use_amp):
            scores_ = self.model(data_, *args)
            losses_ = self.criterion(scores_, targets_, lengths_)
        if not isinstance(losses_, dict):
            losses_ = {'loss': losses_}
        return {k: v.item() for k, v in losses_.items()}
    def calibrate(self):
        """Streams calibration chunks through the model to freeze Brevitas quantizer scales."""
        import brevitas.nn as qnn
        t0 = perf_counter()
        chunks = 0
        # Keep Conv, BatchNorm, and LinearCRFEncoder frozen in FP32 eval mode.
        self.model.eval()
        # Only enable train mode on Brevitas quantizers so they collect percentile stats.
        for m in self.model.modules():
            if isinstance(m, (qnn.QuantIdentity, qnn.QuantLinear)):
                m.train()

        progress_bar = tqdm(
            total=self.steps_per_epoch,
            desc=f'[0/{self.chunks_per_epoch}]',
            ascii=True,
            leave=True,
            ncols=100,
            bar_format='{l_bar}{bar}| [{elapsed}{postfix}]',
            **tqdm_environ()
        )
        smoothed_loss = None
        print(f"\n[PTQ CALIBRATION] Streaming {self.chunks_per_epoch} chunks ({self.steps_per_epoch} steps, batch_size={self.batch_size})...")
        with torch.no_grad(), progress_bar:
            for batch in islice(self.train_loader, self.steps_per_epoch):
                chunks += batch[0].shape[0]
                losses = self.calibrate_one_step(batch)
                smoothed_loss = (
                    losses['loss']
                    if smoothed_loss is None
                    else (0.01 * losses['loss'] + 0.99 * smoothed_loss)
                )
                progress_bar.set_postfix(loss=f'{smoothed_loss:.4f}')
                progress_bar.set_description(f"[{chunks}/{self.chunks_per_epoch}]")
                progress_bar.update()
        # Switch all modules back to eval mode to freeze computed scales
        self.model.eval()
        duration = perf_counter() - t0
        print(f"[PTQ CALIBRATION COMPLETE] Finished in {duration:.1f}s. All activation scales frozen.")
        return smoothed_loss, duration
    def validate_one_step(self, batch):
        """Evaluates one batch and calculates basecalling accuracy."""
        data, targets, lengths, *args = batch
        with amp.autocast("cuda", enabled=self.use_amp):
            scores = self.model(data.to(self.device), *(x.to(self.device) for x in args))
            losses = self.criterion(scores, targets.to(self.device), lengths.to(self.device))
        losses = {k: v.item() for k, v in losses.items()} if isinstance(losses, dict) else losses.item()
        if hasattr(self.model, 'decode_batch'):
            seqs = self.model.decode_batch(scores)
        else:
            seqs = [self.model.decode(x) for x in permute(scores, 'TNC', 'NTC')]
        refs = [decode_ref(target, self.model.alphabet) for target in targets]

        n_pre = getattr(self.model, "n_pre_context_bases", 0)
        n_post = getattr(self.model, "n_post_context_bases", 0)
        if n_pre > 0 or n_post > 0:
            refs = [ref[n_pre:len(ref)-n_post] for ref in refs]

        accs = [
            accuracy(ref, seq, min_coverage=0.5) if len(seq) and len(ref) else 0.0
            for ref, seq in zip(refs, seqs)
        ]
        return seqs, refs, accs, losses
    def validate(self):
        """Runs validation over the validation dataset."""
        print("\n[VALIDATION] Benchmarking basecalling accuracy on validation chunks...")
        self.model.eval()
        seqs_list, refs_list, accs_list, losses_list = [], [], [], []
        total_steps = len(self.valid_loader) if hasattr(self.valid_loader, '__len__') else None
        progress_bar = tqdm(
            self.valid_loader,
            total=total_steps,
            desc='[VALIDATION]',
            ascii=True,
            leave=True,
            ncols=100,
            bar_format='{l_bar}{bar}| [{elapsed}<{remaining}{postfix}]',
            **tqdm_environ()
        )
        with torch.no_grad(), progress_bar:
            for batch in progress_bar:
                seqs, refs, accs, losses = self.validate_one_step(batch)
                seqs_list.extend(seqs)
                refs_list.extend(refs)
                accs_list.extend(accs)
                losses_list.append(losses)
                running_acc = np.mean(accs_list) if accs_list else 0.0
                progress_bar.set_postfix(acc=f'{running_acc:.2f}%')
        loss = np.mean([(x['loss'] if isinstance(x, dict) else x) for x in losses_list])
        mean_acc = float(np.mean(accs_list))
        median_acc = float(np.median(accs_list))
        return loss, mean_acc, median_acc
    def run(self, workdir):
        """Full PTQ pipeline: Calibrate -> Save INT8 Checkpoint -> Validate."""
        workdir = Path(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        # 1. Calibrate activation quantizers
        calib_loss, duration = self.calibrate()
        # 2. Save calibrated model state dict (includes frozen Brevitas scale buffers)
        model_state = self.model.module.state_dict() if hasattr(self.model, 'module') else self.model.state_dict()
        checkpoint_path = workdir / "INT8_weights_0.tar"
        torch.save(model_state, checkpoint_path)
        print(f"[CHECKPOINT] Saved calibrated weights to: {checkpoint_path}")
        # 3. Validate basecalling accuracy
        val_loss, val_mean, val_median = self.validate()
        print("=" * 60)
        print(f"[PTQ EVALUATION RESULTS]")
        print(f"  * Validation Loss   : {val_loss:.4f}")
        print(f"  * Mean Accuracy     : {val_mean:.3f}%")
        print(f"  * Median Accuracy   : {val_median:.3f}%")
        print("=" * 60)
        # 4. Log results to CSV
        with CSVLogger(workdir / 'ptq_results.csv') as log:
            log.append({
                'timestamp': datetime.today(),
                'duration_seconds': int(duration),
                'calibration_loss': calib_loss,
                'validation_loss': val_loss,
                'validation_mean_acc': val_mean,
                'validation_median_acc': val_median,
            })
        return val_mean, val_median