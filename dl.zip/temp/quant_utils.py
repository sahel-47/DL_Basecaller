import torch 
from utils import get_last_checkpoint, get_nth_checkpoint, set_config_defaults, load_symbol, init
from pathlib import Path
import os 
import toml

from collections import OrderedDict
import quantized_transformer
__dir__ = Path(__file__).parent 
__models_dir__ = __dir__ / "models"
__data_dir__ = __dir__ / "data"

def load_fp32_to_quant_model(fp32_state_dict, q_model):
    q_model_state_dict = {} 
    for key, value in fp32_state_dict.items():
        if "Wqkv.weight" in key:

            Wq, Wk, Wv = torch.chunk(value, 3, dim = 0)
            q_model_state_dict[key.replace("Wqkv.weight", "Wq.weight")] = Wq 
            q_model_state_dict[key.replace("Wqkv.weight", "Wk.weight")] = Wk 
            q_model_state_dict[key.replace("Wqkv.weight", "Wv.weight")] = Wv


        elif "Wqkv.bias" in key: 
            bq, bk ,bv = torch.chunk(value,3, dim=0)
            q_model_state_dict[key.replace("Wqkv.bias", "Wq.bias")] = bq
            q_model_state_dict[key.replace("Wqkv.bias", "Wk.bias")] = bk
            q_model_state_dict[key.replace("Wqkv.bias", "Wv.bias")] = bv 

        elif "fc1.weight" in key:
            Wup, Wgate = torch.chunk(value,2, dim=0)
            q_model_state_dict[key.replace("fc1.weight", "Wup.weight")] = Wup 
            q_model_state_dict[key.replace("fc1.weight", "Wgate.weight")] = Wgate

        elif "fc1.bias" in key:
            bup, bgate = torch.chunk(value, 2, dim=0)
            q_model_state_dict[key.replace("fc1.bias", "Wup.bias")] = bup 
            q_model_state_dict[key.replace("fc1.bias", "Wgate.bias")] = bgate

        elif "fc2.weight" in key:
            q_model_state_dict[key.replace("fc2.weight", "Wdown.weight")] = value


        elif "fc2.bias" in key:
            q_model_state_dict[key.replace("fc2.bias", "Wdown.bias")] = value

        elif "norm1.weight" in key: 
            q_model_state_dict[key.replace("norm1.weight", "norm1.g_weights")] = value 

        elif "norm2.weight" in key:
            q_model_state_dict[key.replace("norm2.weight", "norm2.g_weights")] = value 

        else: 
            q_model_state_dict[key] = value 

    incompatible = q_model.load_state_dict(q_model_state_dict, strict=False)
    print(f"[LOAD FP32->QUANT] Missing keys: {len(incompatible.missing_keys)}, Unexpected keys: {len(incompatible.unexpected_keys)}")
    return q_model



def load_quant_to_quant_model(q_state_dict, q_model):
    q_model.load_state_dict(q_state_dict, strict=True)
    return q_model

def load_q_model(dirname, device, weight_type = "FP32", half=False, chunksize = None, batchsize = None, overlap = None, weights = None, use_koi = False):
    if not os.path.isdir(dirname) and os.path.isdir(os.path.join(__models_dir__, dirname)):
        dirname = os.path.join(__models_dir__, dirname)
    weights = get_last_checkpoint(dirname, weight_type) if weights is None else get_nth_checkpoint(dirname, weights, weight_type)
    config = toml.load(os.path.join(dirname,"quant_config.toml"))
    config = set_config_defaults(config, chunksize, batchsize, overlap)
    return _load_q_model(weights, weight_type, config, device, half, use_koi)


def _load_q_model(model_weights, weight_type, config, device, half = False, use_koi = False):
    device = torch.device(device)
    Model = load_symbol(config, "Model")

    model = Model(config)

    if use_koi:
        config["basecaller"]["chunksize"] -= config["basecaller"]["chunksize"] % model.stride
        # overlap must be even multiple of stride for correct stitching
        config["basecaller"]["overlap"] -= config["basecaller"]["overlap"] % (model.stride * 2)
        model.use_koi(
            batchsize=config["basecaller"]["batchsize"],
            chunksize=config["basecaller"]["chunksize"],
            quantize=config["basecaller"]["quantize"],
        )

    model_state_dict = torch.load(model_weights, map_location=device)

    new_state_dict = OrderedDict()

    for k,v in model_state_dict.items():
        name = k.removeprefix("module.") # This happens during multi-GPU training
        new_state_dict[name] = v 

    model = load_fp32_to_quant_model(new_state_dict, model) if weight_type == "FP32" else load_quant_to_quant_model(new_state_dict, model)

    if half:
        model = model.half()

    model.eval() 
    model.to(device)

    return model

def save_q_model(model, dirname, weight_no):
    output_path = os.path.join(dirname, f"_{weight_no}.tar")
    torch.save(model.state_dict(), output_path)

