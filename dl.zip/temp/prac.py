import toml
import torch
from model import Model
from pathlib import Path 

__dir__ = Path(__file__).parent

__models__ = __dir__ / "models"


# Load your config
config = toml.load(__models__ / "config.toml")

# Instantiate on GPU
device = "cuda" if torch.cuda.is_available() else "cpu"
model = Model(config).to(device)
model.eval()

# 12,000 raw samples (stride 6 -> 2,000 output frames)
x = torch.randn(2, 1, 12000, device=device)

with torch.no_grad():
  scores = model(x)
  print(f"Scores shape: {scores.shape}")  # Must be [2000, 2, 5120]
  decoded = model.decode_batch(scores)
  print("Decoded read 0:", decoded[0][:30])