import os 
import sys 
from pathlib import Path 
from time import perf_counter
from itertools import islice 
from datetime import datetime
from ptq import evaluate_model
import toml 
import torch 
import numpy as np 
from tqdm import tqdm 

from brevitas.graph.calibrate import calibration_mode 

from quant_utils import load_q_model, init 
from data import DataSettings, ModelSetup, ComputeSettings, load_data
from utils import decode_ref, permute, accuracy, tqdm_environ
from io_utils import CSVLogger

__dir__ = Path(__file__).parent

class QuantModelEvalArguments:
    pretrained_weights = __dir__ / "quant_models"/"WIN_31_31"
    config_path = pretrained_weights / "quant_config.toml"
    data_dir = __dir__ /"data" / "example_data_dna_r10.4.1_v0"
    output_dir = pretrained_weights / "outputs"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    batchsize = 16
    num_workers = 4
    seed = 42 
    validation_chunks = 2000
    force_overwrite = True 
    weights_name = "INT_QKV8_FFN4"


cfg = QuantModelEvalArguments()
init(cfg.seed, cfg.device, True)
workdir = Path(cfg.output_dir)
workdir.mkdir(parents=True, exist_ok=True)
print(f"[LOADING MODEL]- from {cfg.config_path}")
config = toml.load(cfg.config_path)
print(f"\n[LOADING QUANTIZED WEIGHTS]- from {cfg.pretrained_weights}")
model = load_q_model(cfg.pretrained_weights, cfg.device, cfg.weights_name)
model.to(cfg.device)
print(f"\n[INITIALIZING DATASETS]- from {cfg.data_dir}")

data_settings = DataSettings(
    training_data=cfg.data_dir,
    num_train_chunks=cfg.validation_chunks,
    num_valid_chunks=cfg.validation_chunks,
    output_dir=cfg.output_dir,
)
model_setup = ModelSetup(
    n_pre_context_bases=getattr(model, "n_pre_context_bases", 0),
    n_post_context_bases=getattr(model, "n_post_context_bases", 0),
    standardisation=config.get("standardisation", {}),
)
compute_settings = ComputeSettings(
    batch_size=cfg.batchsize,
    num_workers=cfg.num_workers,
    seed=cfg.seed,
)

train_loader, valid_loader = load_data(data_settings, model_setup, compute_settings)

mean_acc, median_acc = evaluate_model(model, valid_loader, cfg.device)

with CSVLogger(workdir/"ptq_results.csv") as log:
    log.append(
        {
            "timestamp" : datetime.today(),
            "validation_mean_acc" : mean_acc,
            "validation_median_acc" : median_acc,
        }
    )

print(f"[VALIDATION COMPLETED]- Accuracy results saved to {cfg.output_dir}")

